### v2.5
- refine some of the kerning spaces
- Add VTF Monogram
- Block V ª one point to high
- Block й ѝ tilde one point too low
- small adjustments on some characters

### v2.4
- Block V 2 4 5 7 [ § Ĉ Ċ Ē Ĥ ĥ Ю б is one point too high
- Round Ĉ Ċ Ю б Ґ ґ is one point too high
- kerning ГA

### v2.3
- Block B is one point too high
- ajouter eth et dcroat à left_Iacute
- add "Velvetyne Type Foundry" to "Manufacturer" field

### v2.2
- rajouter kerning class left hbar' uni045B
- corriger les caractères doublons (assistant de crénage)
- tout devélopper et condenser le crénage (assistant de crénage)
- corriger métriques fl de la round
- corriger les quelques caractères de la round qui penchent de l'autre côté

### v2.1
- décaler tous les caractères de la "Round" vers la gauche
- simplify the I D in the block
- complexifiy the B, M and W in the borders
- refaire les G accentués en block et borders
- ` (grave) should be lowered